================================================================================
CARA MEMBANGUN (BUILD) APK WARUNGKU UNTUK ANDROID
================================================================================

Proyek ini telah dikonfigurasi lengkap dengan WebView modern, offline cache,
penanganan tombol Back, dan integrasi WhatsApp untuk struk digital.

Terdapat 3 cara mudah untuk menghasilkan file APK (.apk):

--------------------------------------------------------------------------------
METODE 1: MENGGUNAKAN ANDROID STUDIO (PALING UMUM & MUDAH)
--------------------------------------------------------------------------------
1. Download dan ekstrak file ZIP ini ke folder komputer Anda (misal: C:\Warungku)
2. Buka Android Studio di PC / Laptop Anda.
3. Pilih "Open" (atau File -> Open) lalu arahkan ke folder yang Anda ekstrak.
4. Tunggu beberapa saat hingga Android Studio selesai melakukan "Gradle Sync"
   (pastikan koneksi internet terhubung saat pertama kali buka).
5. Untuk membuat APK siap instal:
   - Klik menu atas: "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)"
6. Tunggu proses build selesai (biasanya 30-60 detik).
7. Muncul notifikasi di pojok kanan bawah:
   "APK(s) generated successfully for module 'app' with 1 build variant"
8. Klik tautan "locate" pada notifikasi tersebut.
   File APK Anda sudah jadi di:
   app\build\outputs\apk\debug\app-debug.apk
9. Kirim file app-debug.apk tersebut ke HP Android Anda (via WhatsApp / USB / Google Drive)
   dan langsung install!

--------------------------------------------------------------------------------
METODE 2: VIA COMMAND LINE / TERMINAL (TANPA BUKA ANDROID STUDIO)
--------------------------------------------------------------------------------
Jika komputer Anda sudah terpasang Android SDK & Java 17:
- Pada Windows:
    Buka CMD di folder proyek, ketik:
    gradlew assembleDebug

- Pada Mac / Linux:
    Buka Terminal di folder proyek, ketik:
    ./gradlew assembleDebug

File APK otomatis tersedia di folder:
app/build/outputs/apk/debug/app-debug.apk

--------------------------------------------------------------------------------
METODE 3: OTOMATIS LEWAT GITHUB ACTIONS (TANPA INSTALL SOFTWARE DI PC)
--------------------------------------------------------------------------------
Proyek ini sudah dilengkapi file workflow:
.github/workflows/build-apk.yml

Langkah:
1. Buat repository baru di GitHub (bisa private atau public).
2. Upload seluruh isi folder ini ke repository GitHub Anda.
3. Buka tab "Actions" di repository GitHub Anda.
4. Workflow "Build Warungku APK" akan otomatis berjalan dan meng-compile APK!
5. Setelah selesai, klik run tersebut dan download artifact "Warungku-Debug-APK".
6. Selesai! Anda mendapatkan APK resmi yang langsung bisa dipasang di ponsel.

--------------------------------------------------------------------------------
METODE 4: INSTAL LANGSUNG TANPA APK (PWA / WEBAPK)
--------------------------------------------------------------------------------
Buka aplikasi Warungku lewat browser Google Chrome di HP Android:
1. Tekan tombol menu titik tiga (⋮) di pojok kanan atas Chrome.
2. Pilih "Instal aplikasi" atau "Tambahkan ke Layar Utama".
3. Aplikasi Warungku akan langsung terpasang seperti aplikasi asli dari Play Store
   lengkap dengan ikon Warungku di menu HP Anda!

Selamat menggunakan Warungku - Solusi Kasir UMKM Modern!
